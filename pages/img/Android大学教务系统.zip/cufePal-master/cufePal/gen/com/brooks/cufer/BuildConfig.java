/** Automatically generated file. DO NOT MODIFY */
package com.brooks.cufer;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}