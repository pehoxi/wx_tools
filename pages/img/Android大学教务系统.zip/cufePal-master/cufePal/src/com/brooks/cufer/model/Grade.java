package com.brooks.cufer.model;
public class Grade
{
	private String xn;// ѧ��
	private String xq;// ѧ��
	private String kcdm;// �γ̴���
	private String kcmc;// �γ�����
	private String kcxz;// �γ�����
	private String kcgs;// �γ̹���
	private String xf;// ѧ��
	private String jd;// ����
	private String dj;// �ȼ�
	private String fs;// ����
	private String fxbj;// ���ޱ��
	private String bkcj;// �����ɼ�
	private String cxcj;// ���޳ɼ�
	private String kkxy;// ����ѧԺ
	private String bz;// ��ע
	private String cxbj;// ���ޱ��
	public String getXn()
	{
		return xn;
	}
	public void setXn(String xn)
	{
		this.xn = xn;
	}
	public String getXq()
	{
		return xq;
	}
	public void setXq(String xq)
	{
		this.xq = xq;
	}
	public String getKcdm()
	{
		return kcdm;
	}
	public void setKcdm(String kcdm)
	{
		this.kcdm = kcdm;
	}
	public String getKcmc()
	{
		return kcmc;
	}
	public void setKcmc(String kcmc)
	{
		this.kcmc = kcmc;
	}
	public String getKcxz()
	{
		return kcxz;
	}
	public void setKcxz(String kcxz)
	{
		this.kcxz = kcxz;
	}
	public String getKcgs()
	{
		return kcgs;
	}
	public void setKcgs(String kcgs)
	{
		this.kcgs = kcgs;
	}
	public String getXf()
	{
		return xf;
	}
	public void setXf(String xf)
	{
		this.xf = xf;
	}
	public String getJd()
	{
		return jd;
	}
	public void setJd(String jd)
	{
		this.jd = jd;
	}
	public String getDj()
	{
		return dj;
	}
	public void setDj(String dj)
	{
		this.dj = dj;
	}
	public String getFs()
	{
		return fs;
	}
	public void setFs(String fs)
	{
		this.fs = fs;
	}
	public String getFxbj()
	{
		return fxbj;
	}
	public void setFxbj(String fxbj)
	{
		this.fxbj = fxbj;
	}
	public String getBkcj()
	{
		return bkcj;
	}
	public void setBkcj(String bkcj)
	{
		this.bkcj = bkcj;
	}
	public String getCxcj()
	{
		return cxcj;
	}
	public void setCxcj(String cxcj)
	{
		this.cxcj = cxcj;
	}
	public String getKkxy()
	{
		return kkxy;
	}
	public void setKkxy(String kkxy)
	{
		this.kkxy = kkxy;
	}
	public String getBz()
	{
		return bz;
	}
	public void setBz(String bz)
	{
		this.bz = bz;
	}
	public String getCxbj()
	{
		return cxbj;
	}
	public void setCxbj(String cxbj)
	{
		this.cxbj = cxbj;
	}
	@Override
	public String toString()
	{
		return "Grade [ѧ��=" + xn + ", ѧ��=" + xq + ", �γ̴���=" + kcdm + ", �γ�����="
				+ kcmc + ", �γ�����=" + kcxz + ", �γ̹���=" + kcgs + ", ѧ��=" + xf
				+ ", ����=" + jd + ", �ȼ�=" + dj + ", ����=" + fs + ", ���ޱ��=" + fxbj
				+ ", �����ɼ�=" + bkcj + ", ���޳ɼ�=" + cxcj + ", ����ѧԺ=" + kkxy
				+ ", ��ע=" + bz + ", ���ޱ��=" + cxbj + "]";
	}
}
