/** Automatically generated file. DO NOT MODIFY */
package com.yalantis.contextmenu.lib;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}