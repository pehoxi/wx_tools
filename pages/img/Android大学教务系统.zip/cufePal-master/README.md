# cufePal
中央财经大学教务系统移动端，实现查询课表、查询成绩、查询考试安排、查询空教室等一键解决！


> ![](http://i.imgur.com/B92fFUC.jpg)


> ![](http://i.imgur.com/sv52z2N.jpg)


> ![](http://i.imgur.com/QxRyY9m.jpg)


> ![](http://i.imgur.com/qstmdWg.jpg)


> ![](http://i.imgur.com/6jc7DDd.jpg)
 

> ![](http://i.imgur.com/32Smi0P.jpg)

