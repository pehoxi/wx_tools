package com.jianguo.OA.Model;

import com.jianguo.OA.View.OA_Common_View;

/**
 * Created by ifane on 2016/8/27 0027.
 */
public interface OA_NoticeModel {
    void getNotice(OA_Common_View oa_noticeView);
}
