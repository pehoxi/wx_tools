package com.jianguo.beans;

/**
 * Created by ifane on 2016/8/28 0028.
 */
public class Information_noticeBean {
    String Information_Notice_title;
    String Information_Notice_time;
    String Information_Notice_content;

    public String getInformation_Notice_title() {
        return Information_Notice_title;
    }

    public void setInformation_Notice_title(String information_Notice_title) {
        Information_Notice_title = information_Notice_title;
    }

    public String getInformation_Notice_time() {
        return Information_Notice_time;
    }

    public void setInformation_Notice_time(String information_Notice_time) {
        Information_Notice_time = information_Notice_time;
    }

    public String getInformation_Notice_content() {
        return Information_Notice_content;
    }

    public void setInformation_Notice_content(String information_Notice_content) {
        Information_Notice_content = information_Notice_content;
    }
}
