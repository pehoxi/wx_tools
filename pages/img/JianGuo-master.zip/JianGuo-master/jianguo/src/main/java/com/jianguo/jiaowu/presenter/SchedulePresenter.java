package com.jianguo.jiaowu.presenter;

import android.content.Context;

/**
 * Created by ifane on 2016/5/28 0028.
 */
public interface SchedulePresenter {
    void loadView(Context context,String week);
}
