package com.jianguo.jiaowu.model;

import android.content.Context;

import com.jianguo.jiaowu.view.TestView;

/**
 * Created by ifane on 2016/6/3 0003.
 */
public interface TestModel {
    void loadTest(TestView testView, Context context);
}
