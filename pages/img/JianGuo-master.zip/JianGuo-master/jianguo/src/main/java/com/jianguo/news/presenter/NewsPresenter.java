package com.jianguo.news.presenter;

/**
 * Created by ifane on 2016/5/25 0025.
 */
public interface NewsPresenter {
    //根据新闻类型加载NewsListFragment
    void loadView();
    void loadAdvertisement();

}
