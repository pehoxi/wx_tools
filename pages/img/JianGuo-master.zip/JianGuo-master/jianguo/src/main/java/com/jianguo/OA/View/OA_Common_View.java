package com.jianguo.OA.View;

import com.jianguo.beans.NewsBean;

import java.util.List;

/**
 * Created by ifane on 2016/8/27 0027.
 */
public interface OA_Common_View {
    void setDataBean(List<NewsBean> newsBeen);
}
