package com.jianguo.OA.View;

import android.graphics.Bitmap;

/**
 * Created by ifane on 2016/8/26 0026.
 */
public interface OA_LoginView {
    void setParameter(Bitmap bitmap);
    void success();
    void fail();
}
