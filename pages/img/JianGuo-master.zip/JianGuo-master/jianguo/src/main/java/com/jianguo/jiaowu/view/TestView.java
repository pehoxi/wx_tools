package com.jianguo.jiaowu.view;

import com.jianguo.beans.TestBean;

import java.util.List;

/**
 * Created by ifane on 2016/6/3 0003.
 */
public interface TestView {
    void addTest(List<TestBean> list);
}
