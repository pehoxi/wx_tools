package com.jianguo.OA.View;

import com.jianguo.beans.Information_noticeBean;

/**
 * Created by ifane on 2016/8/27 0027.
 */
public interface OA_Information_NoticeView {
    void setInformation_Notice(Information_noticeBean information_noticeBean);
}
