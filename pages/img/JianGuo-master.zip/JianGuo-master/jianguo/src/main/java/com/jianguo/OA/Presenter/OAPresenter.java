package com.jianguo.OA.Presenter;

/**
 * Created by ifane on 2016/8/26 0026.
 */
public interface OAPresenter {
    void loadNews();
}
