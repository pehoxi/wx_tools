package com.jianguo.beans;

/**
 * Created by ifane on 2016/6/3 0003.
 */
public class ScoreBean {
    private String Score_Name;
    private String Score_grage;
    private String term;

    public String getTerm() {
        return term;
    }

    public void setTerm(String term) {
        this.term = term;
    }

    public String getScore_Name() {
        return Score_Name;
    }

    public void setScore_Name(String score_Name) {
        Score_Name = score_Name;
    }

    public String getScore_grage() {
        return Score_grage;
    }

    public void setScore_grage(String score_grage) {
        Score_grage = score_grage;
    }
}
