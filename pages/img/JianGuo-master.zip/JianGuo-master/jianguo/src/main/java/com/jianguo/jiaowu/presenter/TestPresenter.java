package com.jianguo.jiaowu.presenter;

import android.content.Context;

/**
 * Created by ifane on 2016/6/3 0003.
 */
public interface TestPresenter {
    void loadTestView(Context context);
}
