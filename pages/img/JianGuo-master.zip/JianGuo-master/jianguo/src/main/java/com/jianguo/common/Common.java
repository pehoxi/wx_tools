package com.jianguo.common;

import okhttp3.HttpUrl;

/**
 * Created by ifane on 2016/5/26 0026.
 */
public class Common {
    public static final String NewsList_zhuye="http://www.jiea.cn";
    public static final String SCHEDULE_URL="http://newjwglxt.jiea.cn/jiaowu_system/JWXS/pkgl/XsKB_List.aspx";
    public static final String SCORE_URL="http://newjwglxt.jiea.cn/jiaowu_system/JWXS/cjcx/jwxs_cjcx_like.aspx";
    public static final String TEST_URL="http://newjwglxt.jiea.cn/jiaowu_system/JWXS/ksap/jwxs_ksap_like.aspx";
    public static final String CHECK_CODE="http://newjwglxt.jiea.cn/jiaowu_system/other/CheckCode.aspx?datetime=az";
    public static final String LOGIN_URL="http://newjwglxt.jiea.cn/jiaowu_system/login.aspx";
    public static final String Default="http://newjwglxt.jiea.cn/jiaowu_system/JWXS/Default2.aspx";
    public static final String OA_CHECKCODE="http://oa.jiea.cn:8003/Office/authImg";
    public static final String OA_LOGIN_URL="http://oa.jiea.cn:8003/Office/login/checkLogin.action";
    public static final String OA_OFFICIAL_URL="http://oa.jiea.cn:8003/Office/index/userPubDesktop.action";
    public static final String OA_ZHUYE="http://oa.jiea.cn:8003";
    public static final String HTML_ADAPTER="<body width=320px style=\\\"word-wrap:break-word; font-family:Arial\\\">";
    public static final String AD = "http://blog.zfane.cn/usr/uploads/2016/09/2247130964.json";
}
