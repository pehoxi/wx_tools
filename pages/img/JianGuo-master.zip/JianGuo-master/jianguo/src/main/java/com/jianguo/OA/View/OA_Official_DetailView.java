package com.jianguo.OA.View;

import java.io.File;

/**
 * Created by ifane on 2016/8/27 0027.
 */
public interface OA_Official_DetailView {
    void setPDF(File file);
}
