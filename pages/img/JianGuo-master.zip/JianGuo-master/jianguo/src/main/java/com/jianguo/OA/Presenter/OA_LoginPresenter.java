package com.jianguo.OA.Presenter;

/**
 * Created by ifane on 2016/8/26 0026.
 */
public interface OA_LoginPresenter {
    void loadParameterView();
    void Loginevent(String str1,String str2,String str3);
}
