package com.jianguo.jiaowu;

import android.support.v4.app.FragmentTransaction;

import com.jianguo.R;
import com.jianguo.jiaowu.widget.LoginFragment;

/**
 * Created by ifane on 2016/6/4 0004.
 */
public interface IsLogin {
    void loginSuccess();
    void loginfail();
}
