package com.jianguo.beans;

/**
 * Created by ifane on 2016/6/4 0004.
 */
public class TestBean {
    private String Test_name;
    private String Test_time;
    private String Test_location;
    private String Test_seat;

    public String getTest_name() {
        return Test_name;
    }

    public void setTest_name(String test_name) {
        Test_name = test_name;
    }

    public String getTest_time() {
        return Test_time;
    }

    public void setTest_time(String test_time) {
        Test_time = test_time;
    }

    public String getTest_location() {
        return Test_location;
    }

    public void setTest_location(String test_location) {
        Test_location = test_location;
    }

    public String getTest_seat() {
        return Test_seat;
    }

    public void setTest_seat(String test_seat) {
        Test_seat = test_seat;
    }
}
