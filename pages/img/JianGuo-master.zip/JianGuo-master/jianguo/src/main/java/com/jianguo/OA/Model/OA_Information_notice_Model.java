package com.jianguo.OA.Model;

import com.jianguo.OA.View.OA_Information_NoticeView;

/**
 * Created by ifane on 2016/8/27 0027.
 */
public interface OA_Information_notice_Model {
    void getInformation_Notice(OA_Information_NoticeView oa_information_noticeView,String url);
}
