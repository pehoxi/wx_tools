package com.jianguo.jiaowu.presenter;

/**
 * Created by ifane on 2016/5/31 0031.
 */
public interface LoginPresenter {
    void loadCheckCodeView();
    void getParameterView();
    void loadParameterView();
    void loginevent(String arg1,String arg2,String arg3);

}
