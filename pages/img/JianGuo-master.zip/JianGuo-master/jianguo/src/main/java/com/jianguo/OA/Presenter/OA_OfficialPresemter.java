package com.jianguo.OA.Presenter;

/**
 * Created by ifane on 2016/8/27 0027.
 */
public interface OA_OfficialPresemter {
    void loadOfficial();
}
