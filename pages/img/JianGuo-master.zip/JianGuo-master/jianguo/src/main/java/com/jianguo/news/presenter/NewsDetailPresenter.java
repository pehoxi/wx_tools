package com.jianguo.news.presenter;

import com.jianguo.news.view.NewsDeatil;

/**
 * Created by ifane on 2016/5/27 0027.
 */
public interface NewsDetailPresenter {
    void loadDetailView(String url);
}
