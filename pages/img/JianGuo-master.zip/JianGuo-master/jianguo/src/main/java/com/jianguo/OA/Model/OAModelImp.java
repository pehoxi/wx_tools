package com.jianguo.OA.Model;

/**
 * Created by ifane on 2016/8/26 0026.
 */
public class OAModelImp implements OAModel {
    public void getNews(OAModel oaModel){

    }
}
