package com.jianguo.jiaowu.view;

import com.jianguo.beans.ScheduleBean;

import java.util.List;

/**
 * Created by ifane on 2016/5/28 0028.
 */
public interface ScheduleView {
    void addSchedule(List<ScheduleBean> list);

}
