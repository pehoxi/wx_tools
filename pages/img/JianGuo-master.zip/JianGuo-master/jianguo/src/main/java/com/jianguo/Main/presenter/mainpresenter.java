package com.jianguo.Main.presenter;

/**
 * Created by ifane on 2016/5/25 0025.
 */
public interface MainPresenter {
    void switchNavigation(int id);
}
