# JianGuo
坚果-江西经管院校园APP
# 截图

# 说明
![guide_1](https://github.com/justfz/JianGuo/blob/master/img/guide_1.png)
![guide_2](https://github.com/justfz/JianGuo/blob/master/img/guide_2.png)
![guide_3](https://github.com/justfz/JianGuo/blob/master/img/guide_3.png)
![guide_4](https://github.com/justfz/JianGuo/blob/master/img/Screenshot_20161126-193136.png)
![guide_5](https://github.com/justfz/JianGuo/blob/master/img/Screenshot_20161126-193125.png)
![guide_6](https://github.com/justfz/JianGuo/blob/master/img/Screenshot_1480081105.png)
![guide_7](https://github.com/justfz/JianGuo/blob/master/img/Screenshot_1480081074.png)
- 江西经济管理干部学院校园APP
- 架构：MVP
- 图片加载：Picasso
- 网络请求：OkHttp
- 数据解析：Jsoup 
- 界面：遵循Google Meterial设计
- 浏览校园新闻，查看课表/成绩/考场信息
- 通过模拟登录教务(OA)系统,爬取相关数据

